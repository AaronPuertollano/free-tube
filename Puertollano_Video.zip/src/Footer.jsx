import "./App.css";

function Footer() {
  return (
    <footer>
      <div>
        <p>© 2025 Aaron Puertollano.</p>
      </div>
    </footer>
  );
}

export default Footer;
